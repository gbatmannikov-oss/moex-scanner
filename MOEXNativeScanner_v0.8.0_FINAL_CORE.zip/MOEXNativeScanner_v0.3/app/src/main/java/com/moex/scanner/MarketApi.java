package com.moex.scanner;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;

public final class MarketApi {
    private static final String HOST="https://apim.moex.com";
    private final String token;
    public MarketApi(String token){this.token=token==null?"":token.trim();}
    private String get(String path) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(HOST+path).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestProperty("Accept","application/json");
        if(!token.isEmpty()) c.setRequestProperty("Authorization",token.startsWith("Bearer ")?token:"Bearer "+token);
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String body=new String(in.readAllBytes(),StandardCharsets.UTF_8); if(code<200||code>=300)throw new IOException("HTTP "+code+": "+body); return body;
    }
    public JSONObject futoi(String ticker) throws Exception{return new JSONObject(get("/iss/analyticalproducts/futoi/securities/"+URLEncoder.encode(ticker,"UTF-8")+".json"));}
    public CandleSeries candles(String ticker,int interval,String from) throws Exception{
        String q="/iss/engines/futures/markets/forts/boards/rfud/securities/"+URLEncoder.encode(ticker,"UTF-8")+"/candles.json?interval="+interval+(from==null?"":"&from="+URLEncoder.encode(from,"UTF-8"));
        JSONObject j=new JSONObject(get(q)); JSONObject c=j.optJSONObject("candles");
        if(c==null)return new CandleSeries();
        JSONArray cols=c.optJSONArray("columns"), data=c.optJSONArray("data");
        return new CandleSeries(cols==null?new JSONArray():cols,data==null?new JSONArray():data);
    }
    public static final class CandleSeries { public final JSONArray columns,data; public CandleSeries(){this.columns=new JSONArray();this.data=new JSONArray();} public CandleSeries(JSONArray c,JSONArray d){columns=c;data=d;} }
    public static FutoI parseFutoi(JSONObject root){
        FutoI f=new FutoI(); JSONObject t=root.optJSONObject("futoi"); if(t==null)return f; JSONArray cols=t.optJSONArray("columns"), data=t.optJSONArray("data"); if(cols==null||data==null)return f;
        Map<String,Integer> ix=new HashMap<>(); for(int i=0;i<cols.length();i++)ix.put(cols.optString(i).toUpperCase(),i);
        for(int r=0;r<data.length();r++){JSONArray a=data.optJSONArray(r); if(a==null)continue; String g=s(a,ix,"CLGROUP").toUpperCase(); Side x=new Side(); x.longPos=n(a,ix,"POS_LONG"); x.shortPos=Math.abs(n(a,ix,"POS_SHORT")); x.longNum=n(a,ix,"POS_LONG_NUM"); x.shortNum=n(a,ix,"POS_SHORT_NUM"); if(g.equals("YUR"))f.yur=x; else if(g.equals("FIZ"))f.fiz=x;}
        return f;
    }
    static String s(JSONArray a,Map<String,Integer> m,String k){Integer i=m.get(k);return i==null?"":a.optString(i,"");}
    static double n(JSONArray a,Map<String,Integer> m,String k){Integer i=m.get(k);if(i==null)return 0;Object v=a.opt(i);try{return v instanceof Number?((Number)v).doubleValue():Double.parseDouble(String.valueOf(v));}catch(Exception e){return 0;}}
    public static final class Side {public double longPos,shortPos,longNum,shortNum; public double net(){return longPos-shortPos;}}
    public static final class SideDelta { public double dLong,dShort; public SideDelta(double l,double s){dLong=l;dShort=s;} }
    public static final class FutoDelta { public SideDelta fiz,yur; public double oiChange; }
    public static final class FutoI {public Side fiz=new Side(),yur=new Side(); public double oi(){return fiz.longPos+fiz.shortPos+yur.longPos+yur.shortPos;}}
}
