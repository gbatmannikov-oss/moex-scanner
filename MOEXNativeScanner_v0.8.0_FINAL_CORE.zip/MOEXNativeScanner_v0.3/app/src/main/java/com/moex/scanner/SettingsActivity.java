package com.moex.scanner;
import android.app.*;import android.os.*;import android.widget.*;import android.graphics.Color;
public class SettingsActivity extends Activity{
 SecureStore store; EditText token; TextView result;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);store=new SecureStore(this);token=findViewById(R.id.token);result=findViewById(R.id.result); token.setText(store.get());findViewById(R.id.save).setOnClickListener(v->{try{store.put(token.getText().toString().trim());result.setText("Сохранено на устройстве.");}catch(Exception e){result.setText("Ошибка хранения: "+e.getMessage());}});findViewById(R.id.test).setOnClickListener(v->new Thread(()->{try{MarketApi api=new MarketApi(store.get());api.futoi("Si");runOnUiThread(()->result.setText("Algopack отвечает: FUTOI получен."));}catch(Exception e){runOnUiThread(()->result.setText("Ошибка Algopack: "+e.getMessage()));}}).start());}
}
